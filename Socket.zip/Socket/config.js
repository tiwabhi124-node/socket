var config={
	port:3002,
	portMsg:"3002 for socket",
	isLive:'Yes'
};
module.exports =config;