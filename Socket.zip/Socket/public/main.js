// User - 1
const data = {
  userId: "31",
  roomId: "35",
  players: "2",
  color: "Blue",
  type: "Real",
  gameMode: "Classic",
  value: "10",
  tableId: "85",
  isFree: "No",
  playerType: "Real",
};

socket.emit("joinPrivateRoom", data);

// User - 2
const data = {
  userId: "30",
  roomId: "35",
  players: "2",
  color: "Blue",
  type: "Real",
  gameMode: "Classic",
  value: "10",
  tableId: "85",
  isFree: "No",
  playerType: "Real",
};

socket.emit("joinPrivateRoom", data);

// Response Data for the Pending Players
const responesPendingData = [
  {
    userId: "30",
    roomId: "24",
    players: "2",
    color: "Blue",
    type: "Real",
    gameMode: "Classic",
    value: "10",
    tableId: "41",
    isFree: "No",
    playerType: "Real",
    joinTime: 1621137007234,
  },
  {
    userId: "31",
    roomId: "25",
    players: "2",
    color: "Blue",
    type: "Real",
    gameMode: "Classic",
    value: "10",
    tableId: "41",
    isFree: "No",
    playerType: "Real",
    joinTime: 1621137012419,
  },
];

// EMIT - ROll the Dice

socket.emit("diceRoll", {
  isTest: "Yes",
  diceNumber: 3,
  tableId: "69",
  userId: "30",
  playerType: "Real",
});

// - create new Private Room
socket.emit("createPrivateRoom", {
  players: "2",
  gameMode: "Classic",
  betValue: "10.00",
  roomId: "35",
  isFree: "No",
  playerType: "Real",
});

// ---------------------
// 1- EMIT getPendingmatches
socket.emit("getPendingMatches", { userId: 30 });

// 2- RECEIVE getPendingPlayers

// 3- EMIT sendJoinRequest
socket.emit("sendJoinRequest", {
  // Add Receiver ID
  tableIdTOJoin: "85",
  senderUserId: "30",
  senderUserName: "undefined",
  senderSocketId: "0olvTO8XY3pD6DNgAAAD", // Sender Socker ID
  receiverSocketId: "Rx5k7vOJEBYFFDkZAAAB" //   Receiver Socket ID
});

// 4- RECEIVE receiveJoinRequest

// 5- EMIT- approveJoinRequest
socket.emit("approveJoinRequest", {
  tableIdTOJoin: "85",
  senderSocketId: "Rx5k7vOJEBYFFDkZAAAB",
});

// 6- RECEIVE - approveJoinRequest

// 7- EMIT- joinPrivateRoom using the tableId passed in approveJoinRequest
