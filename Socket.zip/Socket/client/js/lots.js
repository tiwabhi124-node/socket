var lots ={
        "lotCodeList": [
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019051511",
            "lotName": "49-20190515-11",
            "commodityId": "2016070011220000086",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "49201905152",
            "lotName": "49-20190515-2",
            "commodityId": "2016070011220000088",
            "caId": "252804948019418",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "49201904282",
            "lotName": "49-20190428-2",
            "commodityId": "2016040011220000048",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "49201904281",
            "lotName": "49-20190428-1",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019041611",
            "lotName": "49-20190416-11",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019041610",
            "lotName": "49-20190416-10",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "49201904169",
            "lotName": "49-20190416-9",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "49201904168",
            "lotName": "49-20190416-8",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "4920190403102",
            "lotName": "49-20190403-102",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "4920190403101",
            "lotName": "49-20190403-101",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "4920190403100",
            "lotName": "49-20190403-100",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040399",
            "lotName": "49-20190403-99",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040398",
            "lotName": "49-20190403-98",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040397",
            "lotName": "49-20190403-97",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040396",
            "lotName": "49-20190403-96",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040395",
            "lotName": "49-20190403-95",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040394",
            "lotName": "49-20190403-94",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040393",
            "lotName": "49-20190403-93",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040392",
            "lotName": "49-20190403-92",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040391",
            "lotName": "49-20190403-91",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040390",
            "lotName": "49-20190403-90",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040389",
            "lotName": "49-20190403-89",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040388",
            "lotName": "49-20190403-88",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040387",
            "lotName": "49-20190403-87",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040386",
            "lotName": "49-20190403-86",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040385",
            "lotName": "49-20190403-85",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040384",
            "lotName": "49-20190403-84",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040383",
            "lotName": "49-20190403-83",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040382",
            "lotName": "49-20190403-82",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040381",
            "lotName": "49-20190403-81",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040380",
            "lotName": "49-20190403-80",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040379",
            "lotName": "49-20190403-79",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040378",
            "lotName": "49-20190403-78",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040377",
            "lotName": "49-20190403-77",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040376",
            "lotName": "49-20190403-76",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040375",
            "lotName": "49-20190403-75",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040374",
            "lotName": "49-20190403-74",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040373",
            "lotName": "49-20190403-73",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040372",
            "lotName": "49-20190403-72",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040371",
            "lotName": "49-20190403-71",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040370",
            "lotName": "49-20190403-70",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040369",
            "lotName": "49-20190403-69",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040368",
            "lotName": "49-20190403-68",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040367",
            "lotName": "49-20190403-67",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040366",
            "lotName": "49-20190403-66",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040365",
            "lotName": "49-20190403-65",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040364",
            "lotName": "49-20190403-64",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040363",
            "lotName": "49-20190403-63",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040362",
            "lotName": "49-20190403-62",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040361",
            "lotName": "49-20190403-61",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040360",
            "lotName": "49-20190403-60",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040359",
            "lotName": "49-20190403-59",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040358",
            "lotName": "49-20190403-58",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040357",
            "lotName": "49-20190403-57",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040356",
            "lotName": "49-20190403-56",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040355",
            "lotName": "49-20190403-55",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040354",
            "lotName": "49-20190403-54",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040353",
            "lotName": "49-20190403-53",
            "commodityId": "2016040291220000007",
            "caId": "20101491330",
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040351",
            "lotName": "49-20190403-51",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040350",
            "lotName": "49-20190403-50",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040349",
            "lotName": "49-20190403-49",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040348",
            "lotName": "49-20190403-48",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040347",
            "lotName": "49-20190403-47",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040346",
            "lotName": "49-20190403-46",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040345",
            "lotName": "49-20190403-45",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040344",
            "lotName": "49-20190403-44",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040343",
            "lotName": "49-20190403-43",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040342",
            "lotName": "49-20190403-42",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040341",
            "lotName": "49-20190403-41",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040340",
            "lotName": "49-20190403-40",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040339",
            "lotName": "49-20190403-39",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "lotId": "492019040338",
            "lotName": "49-20190403-38",
            "commodityId": "2016040291220000007",
            "caId": null,
            "lotCodeList": null
        }
    ]
    };