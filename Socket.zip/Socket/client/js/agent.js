var agent={
    "statusMsg": "S",
    "bidTranId": null,
    "caId": null,
    "caName": null,
    "caContactNo": null,
    "caEmail": null,
    "caList": [
        {
            "statusMsg": null,
            "bidTranId": null,
            "caId": null,
            "caName": null,
            "caContactNo": null,
            "caEmail": null,
            "caList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "caId": "20101491330",
            "caName": "SAI KRUPA TRDING COMPANY  ",
            "caContactNo": "9885271367",
            "caEmail": null,
            "caList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "caId": "252804948019418",
            "caName": "SRI LAXMI PRASANNA TRADING COMPANY",
            "caContactNo": null,
            "caEmail": null,
            "caList": null
        }
    ]
};