var commodity ={
    "statusMsg": "S",
    "bidTranId": null,
    "commodityId": null,
    "commodityName": null,
    "commodityList": [
        {
            "statusMsg": null,
            "bidTranId": null,
            "commodityId": "2016070011220000088",
            "commodityName": "CHILLI-DELUX",
            "commodityList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "commodityId": "2016070011220000086",
            "commodityName": "CHILLI-DESI",
            "commodityList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "commodityId": "2016040291220000007",
            "commodityName": "CHILLIES",
            "commodityList": null
        },
        {
            "statusMsg": null,
            "bidTranId": null,
            "commodityId": "2016040011220000048",
            "commodityName": "ONION",
            "commodityList": null
        }
    ]
};